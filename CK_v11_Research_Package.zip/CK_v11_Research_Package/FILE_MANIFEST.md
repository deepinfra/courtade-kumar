# Package map

| Path | Purpose |
|---|---|
| `CK_Manuscript_v11.pdf` | Complete 38-page reader/reuse edition, including all technical appendices. |
| `CK_Mechanisms_and_Applications_v11.pdf` | Four-page mathematical entry point, with links to the main paper. |
| `src/` | Complete modular LaTeX source for both PDFs; no external figures or font files required. |
| `tools/finite_instance.py` | Standard-library exact finite-channel/Fourier calculator with rational entropy enclosures. |
| `tools/README.md` | Conventions, commands, precision, limits, and input format. |
| `checks/verify_v9.py` | Unchanged inherited exact/symbolic regression checker. |
| `checks/verify_v11.py` | Selected new identities, finite-model checks, worked examples, and negative controls. |
| `checks/check_source_changes.py` | Inventories changes against the frozen v10 source; rejects unregistered numbered-display edits. |
| `editorial/EDITORIAL_CHANGES.md` | Mathematical dependency changes, promoted scalar theorem, extracted criteria, new corollaries, and scope. |
| `editorial/EQUATION_CROSSWALK.md` | v10 equation/page to v11 equation/page mapping. |
| `editorial/SOURCE_CHANGES.json` | Machine-readable preservation and change inventory. |
| `editorial/v10_to_v11.diff` | Complete module-level source diff. |
| `editorial/COMMUNICATION_AND_ATTRIBUTION.md` | Editorial response to the actual concerns in Tao's essay and Kra's guest post. |
| `editorial/AUTHOR_DISCUSSION_NOTES.md` | Technical questions and answer outlines for explaining the argument without relying on the transcript. |
| `editorial/LITERATURE_RECORD.md` | Primary sources and exact scope of the literature comparison. |
| `editorial/FROZEN_HASHES.json` | Digests of the preserved v10/v9.1 artifacts. |
| `editorial/V10_NUMBERING.aux`, `editorial/V11_NUMBERING.aux` | Numbering snapshots used by the crosswalk. |
| `results/` | Actual build, check, preflight and fresh-reproduction results. |
| `frozen/` | Unchanged v10 PDF/source archive and v9.1 PDF. |
| `reproduce.py` | Rebuilds both PDFs and reruns the scoped checks into a fresh output directory. |
| `verify_integrity.py`, `SHA256SUMS.txt` | Verifies file bytes, not mathematics. |

No superseded exploratory manuscripts outside the frozen baseline source archive are needed to read v11. No model report is a mathematical premise, and no successful Lean build is claimed.
