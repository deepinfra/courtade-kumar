#!/usr/bin/env python3
"""Rebuild the PDFs and rerun scoped checks in a NEW output directory.
No Lean compilation, formal-kernel validation, or independent review is claimed.
"""
from __future__ import annotations
import argparse, hashlib, json, os
from pathlib import Path
import shutil, subprocess, sys
ROOT=Path(__file__).resolve().parent


def run(args, cwd, log):
    with log.open('w') as out:
        process=subprocess.run(args,cwd=cwd,stdout=out,stderr=subprocess.STDOUT,text=True)
    if process.returncode:
        raise RuntimeError(f'Command failed ({process.returncode}); inspect {log}')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True,type=Path);args=ap.parse_args()
    dest=args.output.resolve()
    if dest.exists():raise SystemExit('Refusing to reuse an existing output directory.')
    dest.mkdir(parents=True)
    frozen=json.loads((ROOT/'editorial/FROZEN_HASHES.json').read_text())
    for name,digest in frozen.items():
        if hashlib.sha256((ROOT/'frozen'/name).read_bytes()).hexdigest()!=digest:
            raise SystemExit('Frozen input hash mismatch: '+name)
    if not shutil.which('pdflatex'):raise SystemExit('pdflatex is required for PDF builds.')
    build=dest/'build';build.mkdir()
    for src in (ROOT/'src').glob('*.tex'):shutil.copy2(src,build/src.name)
    for stem in ('CK_Manuscript_v11','CK_Mechanisms_and_Applications_v11'):
        for pass_no in range(1,4):
            run(['pdflatex','-interaction=nonstopmode','-halt-on-error',stem+'.tex'],build,dest/f'{stem}_build_{pass_no}.log')
        text=(build/(stem+'.log')).read_text(errors='replace')
        bad=[line for line in text.splitlines() if 'LaTeX Warning:' in line or 'Overfull' in line or 'undefined references' in line]
        if bad:raise RuntimeError('PDF build warnings: '+repr(bad))
        shutil.copy2(build/(stem+'.pdf'),dest/(stem+'.pdf'))
    run([sys.executable,str(ROOT/'checks/verify_v9.py'),'--symbolic','--output',str(dest/'V9_REGRESSION.json')],ROOT,dest/'V9_REGRESSION.txt')
    run([sys.executable,str(ROOT/'checks/verify_v11.py'),'--output',str(dest/'V11_CHECKS.json')],ROOT,dest/'V11_CHECKS.txt')
    run([sys.executable,str(ROOT/'checks/check_source_changes.py'),'--numbering',str(build/'CK_Manuscript_v11.aux'),'--output',str(dest/'SOURCE_CHANGES.json')],ROOT,dest/'SOURCE_CHANGES.txt')
    run([sys.executable,str(ROOT/'tools/finite_instance.py'),'--example','and','--n','2','--p','1/20','--output',str(dest/'AND_2_example.json')],ROOT,dest/'AND_2_example.txt')
    report={'status':'passed','pdfs_built':['CK_Manuscript_v11.pdf','CK_Mechanisms_and_Applications_v11.pdf'],
            'frozen_hashes_verified':len(frozen),'scope':'PDF production, source inventory, selected exact identities, finite rational arithmetic and finite instances. Not an end-to-end formal proof or independent referee review.',
            'v9_counts':{'rational':json.loads((dest/'V9_REGRESSION.json').read_text())['exact']['count'],'symbolic':json.loads((dest/'V9_REGRESSION.json').read_text())['symbolic']['count']},
            'v11_counts':{'rational':json.loads((dest/'V11_CHECKS.json').read_text())['finite_rational_checks']['count'],'symbolic':json.loads((dest/'V11_CHECKS.json').read_text())['exact_symbolic_identities']['count']}}
    (dest/'REPRODUCTION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
