# Finite examples, exact normalization, and rational entropy intervals

Run from the package root:

```sh
python tools/finite_instance.py --example and --n 2 --p 1/20
python tools/finite_instance.py --example parity --n 3 --p 1/4
python tools/finite_instance.py --example coordinate --n 3 --p 1/20
python tools/finite_instance.py --truth-table tools/and_2.json --p 1/20 --output /tmp/and-result.json
```

The script uses only Python's standard library. Python 3.10+ is required. `checks/verify_v11.py` additionally needs SymPy for selected symbolic identities.

A truth table is a JSON array of zero/one integers in binary-index order. Bit i=1 means X_i=+1, bit i=0 means X_i=-1; the first coordinate is the least significant bit. Thus two-bit AND is `[0,0,0,1]`, and the first coordinate indicator on two bits is `[0,1,0,1]`. Fourier coefficients use sign-output F=2f-1, not indicator normalization.

Exact quantities: posterior probabilities under the finite BSC, means, sign Fourier coefficients and weights, nearest-coordinate distance, and rational recovery coefficients. The output entropy and mutual information are enclosed using the positive logarithm series and explicit remainder in Appendix E. Repeated identical logarithmic terms are collected before enclosure, so coordinate gaps simplify to exact zero. The default truncation is 12 terms; `--terms 18` tightens the intervals. Decimal endpoints are for display only; fraction endpoints decide the reported sign.

A sign reported `inconclusive` is not a failure of the theorem or a successful verification. Increase precision or inspect the exact expression. A strictly negative enclosed claimed slack would warrant investigation of both the implementation and the relevant hypothesis. No universal theorem is inferred from finite examples.

This implementation deliberately limits n to 10. A full truth table has size 2^n, and exact rational entropy evaluation can be expensive. It is a reference calculator, not an efficient high-dimensional algorithm, empirical information estimator, foundational proof kernel, or independent referee.

The test suite compares the tensor posterior implementation against a direct Hamming-distance kernel sum and the fast Fourier transform against direct products of signs on all 278 zero-to-three-bit truth tables. Additional tests cover formulas, invalid inputs, finite examples, and deliberately false normalization identities. These tests support this reference implementation, not arbitrary dimension.
