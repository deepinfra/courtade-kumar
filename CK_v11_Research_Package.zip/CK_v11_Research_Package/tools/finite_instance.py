#!/usr/bin/env python3
"""Exact finite-cube examples and rational entropy enclosures for the CK manuscript.

No floating-point value decides a sign. This tool checks finite instances only;
it is not a proof of a continuous-domain theorem or of arbitrary dimension.
Conventions: index bit i = 1 represents X_i = +1; i = 0 represents X_i = -1.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as Q
from functools import lru_cache
import json
from pathlib import Path
from typing import Iterable

MAX_N = 10
LogForm = dict[Q, Q]  # rational coefficient of log(positive rational)


def checked_values(values: Iterable[int]) -> list[int]:
    v = list(values)
    if not v or len(v) & (len(v) - 1):
        raise ValueError('Truth-table length must be a positive power of two.')
    if len(v) > 1 << MAX_N:
        raise ValueError(f'This finite-instance tool is limited to n <= {MAX_N}.')
    if any(type(x) is not int or x not in (0, 1) for x in v):
        raise ValueError('Truth-table entries must be the integers zero or one.')
    return v


def add_log(form: LogForm, q: Q, coefficient: Q) -> None:
    if q <= 0:
        raise ValueError('A logarithm argument must be positive.')
    if q == 1 or coefficient == 0:
        return
    if q < 1:
        q, coefficient = 1 / q, -coefficient
    form[q] = form.get(q, Q(0)) + coefficient
    if not form[q]:
        del form[q]


def combine(*terms: tuple[Q, LogForm]) -> LogForm:
    out: LogForm = {}
    for scale, form in terms:
        for q, coefficient in form.items():
            add_log(out, q, scale * coefficient)
    return out


def entropy_form(q: Q) -> LogForm:
    if not 0 <= q <= 1:
        raise ValueError('Binary entropy requires a probability in [0,1].')
    form: LogForm = {}
    if q not in (0, 1):
        add_log(form, q, -q)
        add_log(form, 1 - q, -(1 - q))
    return form


@lru_cache(maxsize=65536)
def log_interval(q: Q, terms: int = 12) -> tuple[Q, Q]:
    """Enclose log q by a positive atanh series and its geometric tail bound."""
    if q <= 0 or terms < 1 or terms > 100:
        raise ValueError('Require q > 0 and 1 <= terms <= 100.')
    if q < 1:
        lo, hi = log_interval(1 / q, terms)
        return -hi, -lo
    k = 0
    v = q
    while v >= 2:
        v /= 2
        k += 1
    def series(x: Q) -> tuple[Q, Q]:
        z = (x - 1) / (x + 1)
        lo = 2 * sum((z ** (2 * j + 1) / (2 * j + 1)
                      for j in range(terms)), Q(0))
        tail = 2 * z ** (2 * terms + 1) / ((2 * terms + 1) * (1 - z * z))
        return lo, lo + tail
    lo, hi = series(v)
    lo2, hi2 = series(Q(2))
    return lo + k * lo2, hi + k * hi2


def form_interval(form: LogForm, terms: int = 12) -> tuple[Q, Q]:
    lo = hi = Q(0)
    for q, coefficient in form.items():
        a, b = log_interval(q, terms)
        if coefficient >= 0:
            lo += coefficient * a
            hi += coefficient * b
        else:
            lo += coefficient * b
            hi += coefficient * a
    return lo, hi


def describe_interval(interval: tuple[Q, Q]) -> dict:
    lo, hi = interval
    if lo > hi:
        raise ArithmeticError('Reversed enclosure.')
    sign = ('identically_zero' if lo == hi == 0 else
            'strictly_positive' if lo > 0 else
            'nonnegative' if lo == 0 else
            'strictly_negative' if hi < 0 else
            'inconclusive')
    return {'lower': str(lo), 'upper': str(hi), 'sign': sign,
            'display_lower': float(lo), 'display_upper': float(hi)}


def posterior(values: Iterable[int], p: Q) -> list[Q]:
    v = checked_values(values)
    if not 0 <= p <= Q(1, 2):
        raise ValueError('Noise must lie in [0,1/2].')
    out = list(map(Q, v))
    step = 1
    while step < len(out):
        for base in range(0, len(out), 2 * step):
            for j in range(step):
                a, b = out[base + j], out[base + j + step]
                out[base + j] = (1 - p) * a + p * b
                out[base + j + step] = p * a + (1 - p) * b
        step *= 2
    return out


def sign_fourier(values: Iterable[int]) -> list[Q]:
    v = checked_values(values)
    out = [2 * x - 1 for x in v]
    step = 1
    while step < len(out):
        for base in range(0, len(out), 2 * step):
            for j in range(step):
                a, b = out[base + j], out[base + j + step]
                out[base + j], out[base + j + step] = a + b, a - b
        step *= 2
    return [Q((-1) ** mask.bit_count() * x, len(v)) for mask, x in enumerate(out)]


def coefficient(p: Q) -> Q:
    if not 0 < p < Q(1, 2):
        raise ValueError('The positive recovery coefficient excludes trivial endpoints.')
    rho = 1 - 2 * p
    return 9 * p * rho * rho / 10000 if p < Q(1, 20) else rho * rho / 2000


def analyze(values: Iterable[int], p: Q, terms: int = 12) -> dict:
    v = checked_values(values)
    if not 0 <= p <= Q(1, 2):
        raise ValueError('Noise must lie in [0,1/2].')
    n = len(v).bit_length() - 1
    mu, rho = Q(sum(v), len(v)), 1 - 2 * p
    Fhat, a = sign_fourier(v), posterior(v, p)
    weights = [sum((x * x for mask, x in enumerate(Fhat) if mask.bit_count() == k), Q(0))
               for k in range(n + 1)]
    if sum(weights) != 1:
        raise ArithmeticError('Parseval normalization failed.')
    H = combine(*[(Q(1, len(v)), entropy_form(q)) for q in a])
    hmu, hp = entropy_form(mu), entropy_form(p)
    fair = {Q(2): Q(1)}
    info = combine((Q(1), hmu), (Q(-1), H))
    gap = combine((Q(1), fair), (Q(-1), hp), (Q(-1), info))
    profile = combine((Q(1), H), (-4 * mu * (1 - mu), hp))
    result = {
        'scope': 'Finite example; exact probabilities, Fourier arithmetic and rational log enclosures. Not an all-dimensional proof.',
        'n': n, 'p': str(p), 'rho': str(rho), 'mean': str(mu), 'terms': terms,
        'weights_sign_normalization': [str(x) for x in weights],
        'conditional_entropy_nats': describe_interval(form_interval(H, terms)),
        'mutual_information_nats': describe_interval(form_interval(info, terms)),
        'coordinate_information_gap_nats': describe_interval(form_interval(gap, terms)),
        'profile_deficit_nats': describe_interval(form_interval(profile, terms)),
        'profile_theorem_applicable': p <= Q(1, 20),
    }
    if n:
        b = [Fhat[1 << i] for i in range(n)]
        i = max(range(n), key=lambda j: abs(b[j]))
        delta = (1 - abs(b[i])) / 2
        result.update({'coordinate_correlations': [str(x) for x in b],
                       'nearest_coordinate_one_based': i + 1,
                       'nearest_orientation': 1 if b[i] >= 0 else -1,
                       'distance_to_coordinate': str(delta)})
        upper_slack = combine((Q(1), entropy_form(delta)), (Q(-1), gap))
        result['upper_continuity_slack_nats'] = describe_interval(form_interval(upper_slack, terms))
        if 0 < p < Q(1, 2):
            cp = coefficient(p)
            lo, hi = form_interval(gap, terms)
            result['recovery_coefficient'] = str(cp)
            result['piecewise_stability_slack_nats'] = describe_interval((lo - cp * delta, hi - cp * delta))
        if 0 < p <= Q(1, 20):
            lo, hi = form_interval(profile, terms)
            spectral = p * rho * rho * sum(weights[2:], Q(0)) / 500
            result['spectral_deficit_slack_nats'] = describe_interval((lo - spectral, hi - spectral))
    return result


def example(name: str, n: int) -> list[int]:
    if not 1 <= n <= MAX_N:
        raise ValueError(f'Examples require 1 <= n <= {MAX_N}.')
    if name == 'coordinate': return [j & 1 for j in range(1 << n)]
    if name == 'and': return [int(j == (1 << n) - 1) for j in range(1 << n)]
    if name == 'parity': return [int((-1) ** (n - j.bit_count()) == 1) for j in range(1 << n)]
    if name == 'constant': return [0] * (1 << n)
    raise ValueError('Unknown example.')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    choice = parser.add_mutually_exclusive_group(required=True)
    choice.add_argument('--example', choices=['coordinate', 'and', 'parity', 'constant'])
    choice.add_argument('--truth-table', type=Path, help='JSON array of 0/1 entries in binary index order.')
    parser.add_argument('--n', type=int, default=2, help='Dimension for built-in examples (default 2).')
    parser.add_argument('--p', default='1/20', help='Exact rational flip probability, e.g. 1/20.')
    parser.add_argument('--terms', type=int, default=12, help='Positive-log-series truncation length, 1..100.')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        values = example(args.example, args.n) if args.example else json.loads(args.truth_table.read_text())
        report = analyze(values, Q(args.p), args.terms)
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        parser.error(str(exc))
    text = json.dumps(report, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + '\n')
    print(text)


if __name__ == '__main__':
    main()
