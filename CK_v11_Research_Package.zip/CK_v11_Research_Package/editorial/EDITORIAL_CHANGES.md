# What changes in v11, and what does not

Edition date: 17 September 2026. Baseline: the frozen 36-page v10 exposition, whose mathematical source derives from v9.1. The new PDFs are the 38-page manuscript and the four-page mechanisms/applications companion.

## This is more than a typesetting change

The original CK target, all-means low-noise profile, 1/20 noise division, 13/20 classification cutoff, 31/40 Fourier cap, and existing stability constants are retained. The entropy-curvature derivation, actual scalar estimates, moment polynomial, entropy envelope and finite logarithm enclosures are retained.

However, the main dependency organization changes. The stronger p/500 scalar theorem formerly in v10 Section 6 (v9 Appendix G) is now the central mixing theorem. Consequently the new core presentation uses that already supplied stronger proof, rather than establishing p^2/25 first and returning to repeat the stronger result. This is **not** claimed as a new scalar discovery in v11. An old review of the weaker core is not automatically a review of the reorganized dependency graph.

## Substantive changes to inspect

1. **Restriction--mixing criterion.** The induction is stated for 0 <= c <= h(p), conditional on its all-pair scalar premise at a fixed p. The proof replaces h(p) by c in the induction bookkeeping. This is an extracted general implication, not an extension of the range on which the actual scalar inequality has been established.
2. **One strong scalar proof, in one place.** Product centering and the retained-denominator transfer precede a three-regime statement. Detailed centered estimates and the existing normalized endpoint calculation are together in Appendix A. The p/500 coefficient implies the former p^2/25 coefficient on p <= 1/20.
3. **Spectral-cap certificate.** The already-used energy identity is written with a free cap Omega. A scalar envelope eta >= lambda psi + zeta(1-t) yields the displayed general information-deficit inequality. Its assumptions and two sufficient coefficient conditions are explicit. The applied complementary branch retains its original arguments.
4. **Applications.** Section 7 states the stronger piecewise coefficient already furnished by the two stability branches, identifies the nearest coordinate by its first-level correlation, and proves the elementary upper continuity bound D <= h(delta) by the chain rule. No efficient learning or statistical estimation claim is made.
5. **Limits and examples.** Exact parity and AND calculations distinguish mean gaps from posterior gaps and profile equality from information equality. A small-separation, d=0 Taylor argument proves the upper limit gamma(p) <= 2p(1-p) for any uniform quadratic scalar surplus. It does not rule out a logarithm along actual posterior families, or claim a uniform asymptotic over dimension.

The generalized propositions and Section 7 consequences are author-side mathematical additions, with their proofs displayed. Worldwide novelty of these formulations is not asserted. They should be reviewed as changes, not treated as having inherited approval from an earlier manuscript.

## Preservation checks

The automated equation inventory finds 102 labelled displays in the v10 baseline and 111 in v11. Of the original 102, **96 remain in byte-identical numbered source blocks**, two are rewritten, and four are merged or superseded. These units count labels, so a single align environment can account for more than one label.

The two rewritten labels are `eq:mixing` (promoted p/500 conclusion) and `eq:parent` (posterior and mean-gap statements combined). The four merged/superseded labels are `eq:linear-mixing` (merged into the main mixing theorem), `eq:gap`, `eq:children` (inside the generalized induction), and `eq:quantdeficit` (weaker coordinate estimate superseded by the retained linear-noise version). No unchanged-equations claim is made for the whole v11 manuscript.

`SOURCE_CHANGES.json` and `EQUATION_CROSSWALK.md` identify each old location and its new location. `v10_to_v11.diff` gives the expanded module-by-module source diff. These records establish what was edited, **not the semantic correctness of each edit**.

## Review and formalization status

The document presents a proposed proof, not a statement of community acceptance. Prior private or model review must be described according to its actual scope. No end-to-end Lean or other foundational-kernel proof has been completed by this edition. Earlier Z3 checks are not represented as establishing their analytic or probabilistic premises.

The new checks verify selected identities and finite examples. The unchanged v9 checker is rerun as regression evidence. The new finite-instance utility is not a theorem prover. Its logarithm enclosures use the analytic series and tail bound proved in the manuscript; that proof has not been kernel-replayed here.

The older PDFs and source archive remain unchanged in `frozen/`. Do not overwrite the artifact an existing reviewer is examining.
