# Literature record for this edition

Checked on 17 September 2026. This is a bounded comparison, not an exhaustive novelty or priority determination. Mathematical statements are taken from primary sources; no specialized theorem from these papers is used as an unproved premise in v11.

| Work | Comparison used in the introduction | Primary source |
|---|---|---|
| Kumar and Courtade, *Which Boolean Functions are Most Informative?* | Original Boolean/BSC information-optimization question. The cited arXiv title is not conflated with the differently titled journal version. | https://arxiv.org/abs/1302.2512 |
| Samorodnitsky, *On the entropy of a noisy function*, revised v4 | Abstract explicitly gives the dimension-independent high-noise interval for the unrestricted Boolean problem. | https://arxiv.org/abs/1508.01464 |
| Yu, *Local Optimality of Dictator Functions…*, v5 | Balanced local optimality and the computer-assisted balanced CK result for rho<=0.914. Not presented as an unrestricted all-means solution. | https://arxiv.org/abs/2410.10147 |
| Javanmard and Woodruff, *Progress on the Courtade–Kumar Conjecture…*, v1 | Arbitrary-bias sum of coordinate-wise mutual informations and refined high-noise entropy estimates. The sum is distinguished from information about the full vector. | https://arxiv.org/abs/2601.09679 |
| Friedgut, Kalai and Naor, *FKN, first proof, rewritten* | Context for the classical first-level stability problem. Not a premise of the distance lemma. | https://arxiv.org/abs/2105.03246 |
| Yu and Tan, *An Improved Linear Programming Bound on the Average Distance of a Binary Code* | Retained context for the standard first-level estimate; the manuscript gives its own antipodal proof. | https://arxiv.org/abs/1910.09416 |

The Fu–Wei–Yeung bibliographic entry is retained from the baseline's historical references; this pass does not re-audit that original paper. The elementary bound is proved directly in the manuscript, so source provenance is not substituted for its proof.

The novelty of individual extracted formulations in v11 has not been established worldwide. In particular, the variance identity, antipodal estimate, contraction, the elementary continuity argument, and general moment/polynomial methods are not advertised as newly invented. A novel combination, if valid, must be distinguished from novelty of every ingredient.

Tao's essay and Kra's guest post were read for editorial objectives, not included as mathematical premises. Their authorship and relevant points are documented separately in COMMUNICATION_AND_ATTRIBUTION.md.
