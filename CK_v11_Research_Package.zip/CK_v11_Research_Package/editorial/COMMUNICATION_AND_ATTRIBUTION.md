# Communication, attribution, and the limits of an editorial pass

This is an editorial note, not part of the mathematical bibliography and not a claim that any named mathematician has approved the paper.

## What the relevant criticism actually asks for

Terence Tao's *Mathematics in the age of AI*, Section 6, separates proof generation, verification, communication, community assimilation, and incorporation into a field's working theory. He also warns that polish can conceal the distinction between routine and genuinely difficult steps. Section 8 emphasizes disclosure, attribution, and an author's ability to explain the work. Those are not demands satisfied merely by increasing page quality or model confidence.

The response in v11 is concrete: a conditional scalar-to-cube principle, a fully located product-centering argument, a free-cap entropy certificate, explicit uses and limits, and examples that expose common misreadings. The hardest analytic steps remain identified rather than being described as equally routine. This makes the argument easier to inspect and reuse; it does not demonstrate that an author or reader has already mastered it, or that the community has absorbed it.

Source: Terence Tao, *Mathematics in the age of AI*, arXiv:2608.16753v1, Sections 6 and 8. https://arxiv.org/html/2608.16753v1

The September 13 essay on Tao's blog titled “Deep theorems were scarce and difficult…” is a **guest post by Bryna Kra**. It should not be quoted as though Tao wrote it. Its emphasis on understanding and responsibility motivates the separate discussion notes, not a claim that this PDF settles that debate.

Source: https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/

## Authorship and reuse

The manuscript discloses substantial AI assistance in proof development, checking code, and exposition under the author's direction. This was not limited to spelling or typesetting. Computational outputs and model-review opinions are not mathematical premises. Mathematical references are kept separate from project provenance.

The standard variance identity, antipodal bound, contraction principle, and classical first-level stability background are identified as such. The exposed general criteria are formulations extracted from the candidate; no exhaustive priority survey for each is claimed. The original full theorem and its proposed proof should be judged through the manuscript, not through the review history or an unsupported “first” label.

A responsible discussion still requires answering questions about definitions, domains, proof direction, and how the pieces fit. `AUTHOR_DISCUSSION_NOTES.md` supplies concrete questions and answer outlines. Reading it is preparation, not a certification of understanding. Any unresolved answer should remain recorded as unresolved, rather than being hidden behind the existence of a polished document.
