# Entropy mixing and stability under Boolean noise — v11

## Files to read

`CK_Manuscript_v11.pdf` is the complete 38-page mathematical exposition. `CK_Mechanisms_and_Applications_v11.pdf` is a four-page entry point organized around reusable statements and explicit applications. The manuscript stands on its own; the companion does not replace any proof.

The edition exposes a free-coefficient restriction--mixing criterion, retains the full entropy-product argument, states a reusable spectral-cap/entropy-envelope certificate, and explains quantitative recovery and limits. Detailed scalar estimates are in the appendices, with complete proofs and exact constants.

## What is and is not new

The main CK statement, all-means profile, p<=1/20 scalar range, complementary classification and existing global stability statement are inherited from v10/v9.1. The stronger p/500 scalar theorem, already proved in v9 Appendix G, now replaces the weaker p^2/25 statement in the main route. This removes repeated scalar setup; it is not a new discovery of that margin.

The parameterized criteria, upper continuity bound, and uniform-scalar ceiling are displayed mathematical consequences/extractions with their own proofs. They are not represented as having been reviewed merely because an earlier version was reviewed. They do not assert worldwide priority or expand the input/channel hypotheses.

See `editorial/EDITORIAL_CHANGES.md`, `editorial/EQUATION_CROSSWALK.md`, and the source diff. Of 102 labelled displays in v10, 96 remain in byte-identical source blocks; two are rewritten and four merged/superseded. This is not a claim that the whole proof is unchanged.

## Evidence boundary

This is a proposed analytic proof with a history of checking, not a completed end-to-end proof-assistant artifact. The new finite-instance program and exact checks do not establish the universal analytic claims. Model opinions and private review are not mathematical premises. See `editorial/COMMUNICATION_AND_ATTRIBUTION.md` and the separate preparation notes for discussion.

New execution: 17 exact symbolic identities, 13 finite rational checks, and exact finite-model comparisons on all 278 zero-to-three-bit truth tables, plus 24 interval-enclosed worked examples. The unchanged v9 checker reran 46 exact comparisons and 25 symbolic identities. Actual outputs and narrower scopes are in `results/`.

## Reproduce in a new directory

Python 3.10+, SymPy (version in `requirements.txt`), and pdflatex with the packages named in the TeX sources are required. The finite-instance tool itself is standard-library-only.

```sh
python reproduce.py --output /tmp/ck-v11-new-run
```

The destination must not already exist. The script verifies frozen-input hashes, builds both PDFs, rejects unresolved references/overfull warnings, and runs the source inventory and scoped checks. The build may yield different PDF byte hashes due to creation metadata; the manuscript source and statement inventory remain explicit.

For an exact finite example:

```sh
python tools/finite_instance.py --example and --n 2 --p 1/20
```

The tool accepts JSON truth tables, respects the sign convention, and distinguishes positive/negative/inconclusive interval signs. It is limited to n<=10; it is not a high-dimensional learning algorithm.

## Preservation

`frozen/` contains the original v10 manuscript, its original source archive, and the original v9.1 manuscript, unchanged. The v10 archive also contains the v9.1 mathematical source and earlier preservation records. Do not replace a file currently under review with this edition without telling the reviewer.

`SHA256SUMS.txt` verifies the packaged bytes (excluding itself and its independent checksum listing). Integrity verification is not mathematical verification. The package contains no model-report item in the mathematical reference list and no claim of journal acceptance.
