#!/usr/bin/env python3
"""Inventory v10 -> v11 source changes. This is a preservation check, not a proof checker."""
from __future__ import annotations
import argparse
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import re
import zipfile
ROOT=Path(__file__).resolve().parents[1]
EQ=re.compile(r'\\begin\{(equation\*?|align\*?|gather\*?|multline\*?)\}[\s\S]*?\\end\{\1\}')
ST=re.compile(r'\\begin\{(theorem|lemma|proposition|corollary|remark)\}[\s\S]*?\\end\{\1\}')
LABEL=re.compile(r'\\label\{([^}]+)\}')
REF=re.compile(r'\\(?:eqref|ref|pageref|autoref)\{([^}]+)\}')
EXPECTED_CHANGED={'eq:mixing','eq:parent'}
EXPECTED_REMOVED={'eq:linear-mixing','eq:gap','eq:children','eq:quantdeficit'}
REPLACEMENTS={'eq:linear-mixing':'eq:mixing','eq:gap':'eq:parent','eq:children':'eq:generic-induction','eq:quantdeficit':'eq:linear-coordinate-deficit'}
NOTES={
 'eq:mixing':'The p/500 estimate already proved in v10 section 6 replaces p^2/25. Stronger inherited theorem moved onto the core path.',
 'eq:parent':'Posterior identity and fixed mean-gap inequality combined into one displayed statement.',
 'eq:linear-mixing':'Moved into the main mixing theorem, in expanded M/J notation; no longer stated twice.',
 'eq:gap':'Combined with the posterior identity. No tower/triangle step is dropped from the proof.',
 'eq:children':'The child calculation is written with a general coefficient c in the restriction--mixing proposition.',
 'eq:quantdeficit':'The weaker p^2 coordinate estimate is superseded by the retained noise-linear coordinate estimate.',
}

def old_sources():
    with zipfile.ZipFile(ROOT/'frozen/CK_v10_Exposition_and_Source.zip') as z:
        prefix='CK_v10_Exposition_and_Source/src/'
        if z.read('CK_v10_Exposition_and_Source/checks/verify_v9.py') != (ROOT/'checks/verify_v9.py').read_bytes():
            raise AssertionError('Inherited v9 checker was modified.')
        return {n[len(prefix):]:z.read(n).decode() for n in z.namelist() if n.startswith(prefix) and n.endswith('.tex')}

def blocks(sources,pattern,statements=False):
    out={}
    for filename,text in sources.items():
        if filename.startswith('CK_'):continue
        for match in pattern.finditer(text):
            for label in LABEL.findall(match[0]):
                if statements and label.startswith('eq:'):continue
                if label in out:raise AssertionError('duplicate block label '+label)
                out[label]={'file':filename,'block':match[0]}
    return out

def number_map(path):
    # First two brace groups of each newlabel are the printed number and page.
    if not path.exists():return {}
    return {m[0]:{'number':m[1],'page':m[2]} for m in re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]*)\}\{([^}]*)\}',path.read_text())}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--numbering',type=Path);args=ap.parse_args()
    old=old_sources();new={f.name:f.read_text() for f in (ROOT/'src').glob('*.tex')}
    a,b=blocks(old,EQ),blocks(new,EQ)
    changed={k for k in a if k in b and a[k]['block']!=b[k]['block']}
    removed=set(a)-set(b)
    if changed!=EXPECTED_CHANGED or removed!=EXPECTED_REMOVED:
        raise AssertionError(f'unregistered equation change: changed={changed}; removed={removed}')
    oldnums=number_map(ROOT/'editorial/V10_NUMBERING.aux')
    newnums=number_map(args.numbering or ROOT/'editorial/V11_NUMBERING.aux')
    records=[]
    for k in a:
        status='byte-identical source block' if k in b and a[k]['block']==b[k]['block'] else 'rewritten' if k in b else 'merged or superseded'
        to=REPLACEMENTS.get(k,k)
        records.append({'label_v10':k,'label_v11':to,'status':status,'v10':oldnums.get(k),'v11':newnums.get(to),
                        'old_file':a[k]['file'],'new_file':b[to]['file'] if to in b else None,
                        'note':NOTES.get(k,'Moved or retained without a change to this numbered source block.')})
    src='\n'.join(v for k,v in new.items() if not k.startswith('CK_Mechanisms'))
    labels=LABEL.findall(src);refs=REF.findall(src)
    if len(labels)!=len(set(labels)):raise AssertionError('duplicate labels')
    if set(refs)-set(labels):raise AssertionError('unresolved source refs: '+str(set(refs)-set(labels)))
    ast,bst=blocks(old,ST,True),blocks(new,ST,True)
    result={'status':'passed','baseline':'frozen v10','current':'reader/reuse v11',
            'scope':'Tracks numbered source blocks and references. Does not prove semantic equivalence of rewritten propositions or validate their proofs.',
            'labelled_displays_v10':len(a),'labelled_displays_v11':len(b),
            'unchanged_source_blocks':sum(r['status']=='byte-identical source block' for r in records),
            'changed_labels':sorted(changed),'merged_or_superseded_labels':sorted(removed),
            'new_display_labels':sorted(set(b)-set(a)),
            'statement_changes':{k:('unchanged' if k in bst and ast[k]['block']==bst[k]['block'] else 'rewritten or merged' if k in bst else 'superseded') for k in ast},
            'new_statements':sorted(set(bst)-set(ast)), 'references_checked':len(refs), 'records':records,
            'baseline_zip_sha256':hashlib.sha256((ROOT/'frozen/CK_v10_Exposition_and_Source.zip').read_bytes()).hexdigest()}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2)+'\n')
    # Do not silently revise previous artifacts: source diff is separate.
    unified=[]
    for name in sorted(set(old)|set(new)):
        if name.startswith('CK_Research_Overview') or name.startswith('CK_Mechanisms'):continue
        unified.extend(difflib.unified_diff(old.get(name,'').splitlines(True),new.get(name,'').splitlines(True),fromfile='v10/'+name,tofile='v11/'+name))
    (args.output.parent/'v10_to_v11.diff').write_text(''.join(unified))
    lines=['# Numbered-equation crosswalk: v10 to v11','',
           'These are source-preservation statuses, not correctness verdicts. Read EDITORIAL_CHANGES.md for the semantic changes.','',
           '| v10 equation / page | v11 equation / page | Source status | Role |','|---|---|---|---|']
    for rec in records:
        def fmt(n):return 'not numbered' if not n else f"{n['number']} / p. {n['page']}"
        lines.append(f"| {fmt(rec['v10'])} | {fmt(rec['v11'])} | {rec['status']} | {rec['note']} |")
    (args.output.parent/'EQUATION_CROSSWALK.md').write_text('\n'.join(lines)+'\n')
    print('PASSED: ',result['unchanged_source_blocks'],'byte-identical inherited labelled displays;',len(changed),'rewritten;',len(removed),'merged/superseded;',len(refs),'resolved source references.')
if __name__=='__main__':main()
