#!/usr/bin/env python3
"""New v11 identities, finite normalization checks, and negative controls.
This is NOT foundational or end-to-end verification of the CK proof.
The general statements require the analytic/probabilistic arguments in the paper.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as Q
import hashlib
import itertools
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import finite_instance as fi


def demand(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def symbolic_checks() -> list[str]:
    import sympy as s
    r, d, c, V, e, h, lam, m, Om, W1, tail, FG, ER, EG2 = s.symbols('r d c V e h lam m Om W1 tail FG ER EG2', real=True)
    checks = []
    def ident(name, expr):
        demand(s.simplify(s.cancel(s.expand(expr))) == 0, name)
        checks.append(name)
    a,b = s.symbols('a b', real=True)
    prof = lambda x: 4*x*(1-x)
    ident('variance restriction identity', (prof(a)+prof(b))/2-prof((a+b)/2)+(b-a)**2)
    ident('generic induction remainder', c*(V-d*d)+2*c*d*e-(1+d*d)*c*V - (2*c*d*(e-d)+c*d*d*(1-V)))
    K,M,K0,M0,ell,gamma,C=s.symbols('K M K0 M0 ell gamma C', real=True)
    ident('completed square', K+M*d*d-2*ell*d - ((M*d-ell)**2+K*M-ell**2)/M)
    ident('product-margin transfer polynomial remainder', (K+M*d*d-2*ell*d-gamma/C)*C*M - (C*(M*d-ell)**2+C*(K*M-K0*M0)+C*(K0*M0-ell**2-gamma)+gamma*(C-M)))
    J,H,H0,H1,S,tgap=s.symbols('J H H0 H1 S tgap', real=True)
    # S=(1+d^2)H-J-2dh*e and J is average child entropy.
    ident('entire deficit identity', (1+d*d)*(H-V*h) - (((1+d*d)*H-J-2*d*h*e)+(J-(V-d*d)*h)+2*d*h*(e-d)+d*d*(1-V)*h))
    E,T=s.symbols('E T', real=True)
    ident('generic spectral induction surplus', lam*r*r*(E-T)+lam*(d*d+r*r*T)-(1+d*d)*lam*r*r*E-lam*d*d*(1-r*r*E))
    Lambda=1+r-Om*r*r
    Gamma=1+r-r*r
    sCap=Om-m*m-W1
    EG2exact=r*r*FG+(1-r*r)*m*m+r*r*(1-r)*W1-tail
    ident('energy identity for a free cap', (1-r*r+r*r*ER-EG2exact)-(1-r)*(Lambda-Gamma*m*m)-(r*r*(ER-FG)+tail+r*r*(1-r)*sCap))
    etaR,etar,zeta,log2=s.symbols('etaR etar zeta log2', real=True)
    entropyLower=lam*(1-r)*(Lambda-Gamma*m*m)+zeta*(1-ER)
    derived=(log2-etar)-((log2-m*m/2)-entropyLower)
    desired=lam*(1-r)*Lambda-etar+m*m*(s.Rational(1,2)-lam*(1-r)*Gamma)+zeta*(1-ER)
    ident('generic Fourier-to-entropy certificate', derived-desired)
    Ijoint,If,Ig=s.symbols('Ijoint If Ig', real=True)
    ident('conditional mutual information chain cancellation', (Ijoint-If)-(Ijoint-Ig)-(Ig-If))
    corr,orient=s.symbols('corr orient', real=True)
    ident('disagreement from signed correlation', 1-(1+orient*corr)/2-(1-orient*corr)/2)
    beta=s.symbols('beta', real=True)
    ident('section cap single square', beta**2+(s.Rational(1,2)-beta)/2-(beta-s.Rational(1,4))**2-s.Rational(3,16))
    p,t=s.symbols('p t', real=True)
    eta=lambda x:s.log(2)-((1+x)*s.log(1+x)+(1-x)*s.log(1-x))/2
    ident('actual entropy first derivative at zero', s.diff(eta(t),t).subs(t,0))
    ident('actual entropy second derivative at zero', s.diff(eta(t),t,2).subs(t,0)+1)
    ident('quadratic coefficient at centered small separation', s.diff(eta(r*t)-eta(t),t,2).subs(t,0)/2-(1-r*r)/2)
    ident('scalar upper-limit noise normalization', (1-(1-2*p)**2)/2-2*p*(1-p))
    x,y=s.symbols('x y', real=True)
    Fand=(-1+x+y+x*y)/2
    ident('AND Fourier polynomial equals indicator sign', Fand-(2*((1+x)/2)*((1+y)/2)-1))
    ident('two-bit parity effective noise', (1-(1-2*p)**2)/2-2*p*(1-p))
    return checks


def rational_checks() -> list[dict]:
    checks=[]
    def ck(name, value):
        demand(value, name);checks.append({'name':name,'passed':True})
    ck('recovery coefficient at p=1/4',fi.coefficient(Q(1,4))==Q(1,8000))
    ck('recovery example is exactly 1/125',Q(1,10**6)/fi.coefficient(Q(1,4))==Q(1,125))
    ck('upper branch wins at shared endpoint',Q(1,2000)>9*Q(1,20)/10000)
    ck('low piecewise lower margin improves the global coefficient',Q(9,10000)>Q(1,2000))
    ck('high piecewise margin implies global for p<=1/2',Q(1,2000)>Q(1,2)/2000)
    ck('strong scalar margin dominates weak exactly up to cutoff',Q(1,500)==Q(1,20)/25)
    ck('scalar upper limit exceeds the supplied coefficient at largest p',2*(1-Q(1,20))>Q(1,500))
    # Independent known series identity for ln2 is tested by nested enclosures,
    # not called a formal proof of the logarithm theorem.
    lo,hi=fi.log_interval(Q(2),12);lo2,hi2=fi.log_interval(Q(2),18)
    ck('log enclosures nested at ln2',lo<lo2<hi2<hi)
    ck('ln2 enclosure is sufficiently narrow',hi-lo<Q(1,10**12))
    ck('log reciprocal reverses interval',fi.log_interval(Q(1,2),12)==(-hi,-lo))
    ck('log power-two exact reduction',fi.log_interval(Q(8),12)==(3*lo,3*hi))
    ck('binary entropy endpoints represented exactly',fi.entropy_form(Q(0))=={} and fi.entropy_form(Q(1))=={})
    ck('binary entropy symmetry represented exactly',fi.entropy_form(Q(2,7))==fi.entropy_form(Q(5,7)))
    return checks


def finite_checks() -> dict:
    counts={'truth_tables':0,'direct_fourier_equalities':0,'direct_kernel_equalities':0,
            'posterior_mean_equalities':0,'coordinate_distance_equalities':0,
            'conditional_entropy_symmetries':0,'examples_with_enclosed_slacks':0,
            'rejected_bad_inputs':0,'false_identity_controls_rejected':0}
    noise=[Q(0),Q(1,20),Q(1,4),Q(1,2)]
    for n in range(4):
        N=1<<n
        for code in range(1<<N):
            v=[(code>>j)&1 for j in range(N)]
            counts['truth_tables']+=1
            coeff=fi.sign_fourier(v)
            for mask in range(N):
                # Independent direct product of signs, not another Walsh transform.
                direct=sum(Q(2*v[j]-1)*Q(-1 if (mask.bit_count()-(j&mask).bit_count())%2 else 1)
                           for j in range(N))/N
                demand(coeff[mask]==direct, f'Fourier sign normalization n={n} mask={mask}')
                counts['direct_fourier_equalities']+=1
            if n:
                distances=[Q(sum((2*v[j]-1)!=sigma*(1 if j&(1<<i) else -1) for j in range(N)),N)
                           for i in range(n) for sigma in (-1,1)]
                demand(min(distances)==(1-max(abs(coeff[1<<i]) for i in range(n)))/2,'distance identity')
                counts['coordinate_distance_equalities']+=1
            for p in noise:
                post=fi.posterior(v,p)
                for y in range(N):
                    direct=sum((Q(v[x])*p**((x^y).bit_count())*(1-p)**(n-(x^y).bit_count())
                                for x in range(N)), Q(0))
                    demand(post[y]==direct, 'BSC tensor vs direct kernel')
                    counts['direct_kernel_equalities']+=1
                demand(sum(post)/N==Q(sum(v),N), 'posterior tower identity')
                counts['posterior_mean_equalities']+=1
    # Independent brute Fourier and direct kernel cover all n<=3, not all n.
    examples=[]
    for name,n in [('constant',1),('coordinate',3),('and',2),('parity',2),('parity',3),('and',4)]:
        for p in [Q(1,100),Q(1,20),Q(1,4),Q(2,5)]:
            report=fi.analyze(fi.example(name,n),p)
            check_fields=['coordinate_information_gap_nats','upper_continuity_slack_nats',
                          'piecewise_stability_slack_nats']
            if p<=Q(1,20):check_fields += ['profile_deficit_nats','spectral_deficit_slack_nats']
            for field in check_fields:
                demand(report[field]['sign'] in ('identically_zero','strictly_positive','nonnegative'),
                       f'enclosure inconclusive or negative: {name},{p},{field}')
            if name=='coordinate':
                demand(report['coordinate_information_gap_nats']['sign']=='identically_zero',
                       'coordinate gap must simplify to exact zero')
            examples.append({'example':name,'n':n,'p':str(p),'enclosed_fields':check_fields})
            counts['examples_with_enclosed_slacks']+=1
    # The AND and parity exact posterior formulas do not use log evaluations.
    for p in [Q(1,100),Q(1,20),Q(1,4),Q(2,5)]:
        demand(sorted(fi.posterior(fi.example('and',2),p))==sorted([p*p,p*(1-p),p*(1-p),(1-p)**2]),'AND formula')
        counts['conditional_entropy_symmetries']+=1
        for n in [2,3,4]:
            post=fi.posterior(fi.example('parity',n),p);r=1-2*p
            demand(set(post)=={(1-r**n)/2,(1+r**n)/2},'parity formula')
            counts['conditional_entropy_symmetries']+=1
    invalid=[lambda:fi.checked_values([0,1,0]), lambda:fi.checked_values([0,2]),
             lambda:fi.posterior([0,1],Q(3,4)),lambda:fi.log_interval(Q(0)),
             lambda:fi.entropy_form(Q(-1,5)),lambda:fi.coefficient(Q(0)),
             lambda:fi.coefficient(Q(1,2)),lambda:fi.example('parity',11)]
    for action in invalid:
        try: action()
        except ValueError: counts['rejected_bad_inputs']+=1
        else: raise AssertionError('Invalid input accepted')
    # Deliberately false variants (not false CK claims).
    demand(fi.sign_fourier([0,1])[1] != -1,'reversed coordinate normalization wrongly accepted')
    counts['false_identity_controls_rejected']+=1
    v=fi.example('parity',2);p=Q(1,4)
    correct=2*p*(1-p)
    demand(correct != p,'wrong parity effective noise not rejected')
    counts['false_identity_controls_rejected']+=1
    # d is zero for parity sections, but their posterior difference is nonzero.
    A=fi.posterior([0,1],p);B=fi.posterior([1,0],p)
    demand(Q(sum([0,1]),2)-Q(sum([1,0]),2)==0 and abs(A[0]-B[0])>0,
           'mean-gap/posterior-gap false identification not rejected')
    counts['false_identity_controls_rejected']+=1
    return {'counts':counts,'examples':examples}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    symbolic=symbolic_checks();rational=rational_checks();finite=finite_checks()
    report={'status':'passed','exact_symbolic_identities':{'count':len(symbolic),'names':symbolic},
            'finite_rational_checks':{'count':len(rational),'checks':rational},'finite_model_checks':finite,
            'scope':'Selected exact identities and finite-model checks. No end-to-end formal proof, no independent referee verdict, no all-domain numerical proof.',
            'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n')
    print('PASSED',len(symbolic),'symbolic identities;',len(rational),'rational checks; finite scope:',finite['counts'])

if __name__=='__main__':main()
