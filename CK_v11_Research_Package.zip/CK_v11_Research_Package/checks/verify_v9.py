#!/usr/bin/env python3
"""V9 exact arithmetic and symbolic identities. No sampled test proves a universal sign."""
from __future__ import annotations
import argparse, hashlib, json
from fractions import Fraction as F
from pathlib import Path


def require(value: bool, message: str) -> None:
    if not value: raise ArithmeticError(message)


def ln_interval(q: F, n: int = 12) -> tuple[F, F]:
    q=F(q)
    if q<=0: raise ValueError('Positive logarithm argument required')
    if q<1:
        a,b=ln_interval(1/q,n); return -b,-a
    def series(v: F) -> tuple[F,F]:
        require(F(1)<=v<=F(2),'log reduction domain')
        z=(v-1)/(v+1)
        lo=2*sum((z**(2*j+1)/F(2*j+1) for j in range(n)),F(0))
        return lo,lo+2*z**(2*n+1)/(F(2*n+1)*(1-z*z))
    k=0
    while q>=2: q/=2;k+=1
    a,b=series(q);c,d=series(F(2))
    return a+k*c,b+k*d


def entropy_interval(q: F) -> tuple[F,F]:
    q=F(q)
    if not 0<=q<=1: raise ValueError('Entropy domain')
    if q in (0,1):return F(0),F(0)
    a,b=ln_interval(1/q);c,d=ln_interval(1/(1-q))
    return q*a+(1-q)*c,q*b+(1-q)*d


def exact_checks() -> dict:
    checks=[]; margins=[]
    def ck(name: str, value: bool, detail=''):
        require(value,name);checks.append({'name':name,'passed':True,'detail':str(detail)})
    def margin(name,interval,target,cert):
        lo,hi=interval;lo-=target;hi-=target
        ck(name,lo>cert and hi-lo<F(1,10**11))
        margins.append({'name':name,'lower':str(lo),'upper':str(hi),'width':str(hi-lo),
                        'certified_lower_margin':str(cert),'decimal_lower_for_reading':float(lo)})
    L2,U2=ln_interval(F(2))
    ck('ln2 precision uses the twelve-term series',U2-L2<F(1,10**12),U2-L2)
    margin('ln(127/40)-11553/10000',ln_interval(F(127,40)),F(11553,10000),F(7,10**6))
    margin('ln(3967/1000)-689/500',ln_interval(F(3967,1000)),F(689,500),F(1,100000))
    l20,u20=ln_interval(F(20))
    margin('749/250-ln(20)',(-u20,-l20),-F(749,250),F(1,4000))
    margin('h(1/5)-1/2',entropy_interval(F(1,5)),F(1,2),F(1,2500))
    margin('ln(199/60)-599/500',ln_interval(F(199,60)),F(599,500),F(9,10000))
    for rho,coef,cert in [(F(3,4),F(287,250),F(1,20000)),(F(17,20),F(1377,1000),F(1,40000))]:
        a,b=ln_interval(2/(1-rho));lam=1+rho-F(31,40)*rho*rho
        lo=coef-(b+F(3,4)+rho/4)/(2*lam);hi=coef-(a+F(3,4)+rho/4)/(2*lam)
        margin('lambda_j-lambda_bar at '+str(rho),(lo,hi),F(0),cert)
    # New normalized transfer constants, calculated without a symbolic package.
    ck('interior margin dominates ln2/500',F(1999,1250000)>F(7,5000)>U2/500)
    ck('small-endpoint margin dominates 1/500',F(23,3600)>F(1,500))
    ck('large-endpoint normalized margin dominates 1/500',F(453,40000)>F(1,500))
    ck('boundary phi(c,1)',(F(299,100)**2-F(51,20)*F(299,100)-F(49,40))/(2*F(299,100)+F(9,20))==F(453,32150))
    ck('boundary ordering',F(453,32150)>F(453,40000))
    ck('phi derivative lower polynomial at 14/5',F(14,5)**2-F(41,20)*F(14,5)-F(37,60)==F(89,60))
    ck('phi derivative lower polynomial increasing',2*F(14,5)-F(41,20)>0)
    ck('boundary inverse bound',1/(1-F(1,5))==F(5,4))
    ck('boundary first factor below 3',F(299,100)-F(1,6)<3)
    ck('boundary beta below 4',F(299,100)+F(19,20)<4)
    ck('boundary denominator below 8',F(3)+F(5,4)*4==8)
    ck('linear margin implies retained quadratic margin at all p<=1/20',F(1,500)==F(1,20)/25)
    ck('new one-coordinate coefficient',F(1,500)/F(5,4)==F(1,625))
    ck('low-noise bias coefficient pays spectral mean',F(1,2)-F(1,5)>F(1,20)/500)
    ck('coordinate-distance large-bias case',F(20,9)*F(13,20)**2>F(1,2))
    ck('coordinate-distance large-coordinate case',F(10,13)<F(20,9))
    ck('coordinate-distance remainder class',F(20,9)*F(9,40)==F(1,2))
    ck('low-noise distance coefficient',F(9,20)/500==F(9,10000)>F(1,2000))
    # Complementary stability with v8's cutoff, not v6's old cutoff.
    ck('large-bias deficit',F(1,2)-F(391,800)==F(9,800))
    ck('coordinate chord slope',2/(1-F(13,20))==F(40,7))
    ck('C2 lower endpoint',F(7,20)*(F(33,40)-F(7,10))==F(7,160))
    ck('C2 upper endpoint normalized',F(3,10000)/(F(81,100)*F(19,100))==F(1,513))
    ck('C2 endpoint comparison',F(7,160)>F(1,513))
    ck('coordinate rho-squared bound',F(1,513)*F(19,100)==F(1,2700))
    ck('coordinate stability coefficient',F(40,7)*F(1,2700)==F(2,945)>F(1,2000))
    bern=[F(393,10000),F(829,75000),F(1249,60000),F(31,400),F(1683,40000),F(11161,300000),F(13493,200000),F(21353,600000),F(493,30000),F(273,25000)]
    ck('minimum Bernstein margin',min(bern)==F(273,25000))
    ck('Lambda endpoints above 5/4',min(1+r-F(31,40)*r*r for r in (F(3,5),F(9,10)))>F(5,4))
    ck('remainder variance factor',F(5,4)*(1-F(13,20)**2)>F(2,3))
    ck('posterior uncertainty lower bound',F(1,10)*F(2,3)/F(41,25)==F(5,123)>F(1,25))
    ck('middle-noise uniform surplus',F(273,25000)/2/F(25)>F(81,100)*F(1,2)/2000)
    anchor=F(39,40)*F(2,5)*F(1321,1000)
    ck('strict anchor U0<179/1000',U2-anchor<F(179,1000))
    ck('high-noise degradation margin',F(1,2)-F(179,1000)/F(9,25)==F(1,360)>F(1,4000))
    ck('high-to-global weakening p<=1/2',F(1,2000)>F(1,2)/2000)
    # Two exact small examples check Fourier child bookkeeping without numerical entropy.
    for n,vals in [(2,[-1,-1,-1,1]),(3,[-1,1,1,-1,1,-1,-1,1])]:
        N=1<<n
        def coeff(f):
            return [sum(F(v)*(-1)**((i&j).bit_count()) for i,v in enumerate(f))/len(f) for j in range(len(f))]
        C=coeff(vals);rr=sum(x*x for j,x in enumerate(C) if j.bit_count()>=2)
        for i in range(n):
            children=[[v for j,v in enumerate(vals) if ((j>>i)&1)==bit] for bit in (0,1)]
            rch=[sum(x*x for j,x in enumerate(coeff(ch)) if j.bit_count()>=2) for ch in children]
            T=sum(C[j]*C[j] for j in range(N) if j.bit_count()==2 and j&(1<<i))
            ck(f'child spectral loss n={n},coordinate={i}',sum(rch)/2==rr-T)
    return {'count':len(checks),'checks':checks,'certified_margins':margins,'scope':'Finite exact rational statements. Analytic quantifiers are proved in the manuscript.'}


def symbolic_checks() -> dict:
    import sympy as s
    u,r,v,d,t,nu,p=s.symbols('u r v d t nu p',real=True)
    checks=[]
    def eq(name,expr):
        val=s.simplify(s.cancel(s.expand(expr)))
        require(val==0,name+': '+str(val));checks.append(name)
    # Log form on (-1,1): atanh is represented by its exact real-log identity.
    at=lambda x:(s.log(1+x)-s.log(1-x))/2
    eta=lambda x:s.log(2)-((1+x)*s.log(1+x)+(1-x)*s.log(1-x))/2
    k=lambda x:1/(1-x*x)
    Q=(eta(nu+t)+eta(nu-t))/2
    L=(at(nu+t)+at(nu-t))/2
    C=(eta(nu-t)+eta(nu+t))*(k(nu+t)-k(nu-t))-(at(nu+t)**2-at(nu-t)**2)
    eq('exact entropy derivative',s.diff(eta(u),u)+at(u))
    eq('exact L=-Q_nu',L+s.diff(Q,nu))
    eq('exact mixed derivative Q^2=-C/2',s.diff(Q*Q,nu,t)+C/2)
    eq('exact d_t(QL)=C/4',s.diff(Q*L,t)-C/4)
    # The opposite region is exactly the same expression, by eta(-x)=eta(x),
    # k(-x)=k(x), at(-x)=-at(x). Verify those transformations algebraically.
    eq('entropy evenness',eta(-u)-eta(u));eq('curvature evenness',k(-u)-k(u));eq('atanh oddness',at(-u)+at(u))
    du=(1-u*u)**2/(2*u)
    gp=s.diff(eta(u),u)*du
    gpp=s.diff(gp,u)*du
    eq('exact curvature g prime',gp+(1-u*u)**2*at(u)/(2*u))
    eq('exact curvature g double prime',gpp-(1-u*u)**3*((1+3*u*u)*at(u)-u)/(4*u**3))
    w=2*u*eta(u)-(1-u*u)*at(u)
    eq('exact g+v g prime identity',eta(u)+gp/(1-u*u)-w/(2*u))
    eq('exact w prime',s.diff(w,u)-(2*eta(u)-1));eq('exact w double prime',s.diff(w,u,2)+2*at(u))
    eq('exact atanh-squared curvature derivative',s.diff(at(u)**2,u)*du+2*gp/(1-u*u))
    eq('gain-integral derivative, all interior t,rho',s.diff(eta(r*t),r)+t*at(r*t))
    # Noise-linear strengthening.
    A=u-s.Rational(1,2)+(r-1)/(3*r);B=u+s.Rational(19,20);H=A+r*B;Z=u+s.log(r)+1
    phi=A-Z*Z/H
    eq('phi derivative identity',s.diff(phi,r)-(s.diff(A,r)+Z*(Z*r*s.diff(H,r)-2*H)/(r*H*H)))
    eq('phi derivative bracket decomposition',Z*r*s.diff(H,r)-2*H-(Z*r*s.diff(A,r)+r*B*(Z-2)-2*A))
    eq('phi derivative lower polynomial',B*(u-1)-2*(u-s.Rational(1,6))-(u*u-s.Rational(41,20)*u-s.Rational(37,60)))
    R=A*H-Z*Z
    eq('normalized discriminant identity',phi-R/H)
    eq('r=1 boundary phi',phi.subs(r,1)-(u*u-s.Rational(51,20)*u-s.Rational(49,40))/(2*u+s.Rational(9,20)))
    eq('boundary derivative numerator',s.diff(phi.subs(r,1),u)*(2*u+s.Rational(9,20))**2-(2*u*u+s.Rational(9,10)*u+s.Rational(521,400)))
    # Refined induction, with r_F denoted e to avoid the endpoint ratio r.
    e,T,d2,ell,rho=s.symbols('e T d2 ell rho')
    eq('spectral induction exact surplus',ell*rho**2*(e-T)+ell*(d2+rho**2*T)-(1+d2)*ell*rho**2*e-ell*d2*(1-rho**2*e))
    m,q,b,Ti=s.symbols('m q b Ti')
    eq('average child spectral residual',(1-m*m-b*b)-(q-b*b+Ti)-(1-m*m-q-Ti))
    eq('mean plus spectral residual',m*m+(1-m*m-q)-(1-q))
    eq('coordinate section cap',b*b+1-b-(1-b*(1-b)))
    eq('Gamma upper quadratic',1+rho-rho*rho-(s.Rational(5,4)-(rho-s.Rational(1,2))**2))
    return {'count':len(checks),'checks':checks,'scope':'Identities simplified exactly, not evaluated at sample points. Log identities require the stated real interior domains.'}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default='V9_CHECKS.json');ap.add_argument('--symbolic',action='store_true');args=ap.parse_args()
    result={'exact':exact_checks(),'status':'passed','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    if args.symbolic:result['symbolic']=symbolic_checks()
    Path(args.output).parent.mkdir(parents=True,exist_ok=True)
    Path(args.output).write_text(json.dumps(result,indent=2))
    print('PASSED',result['exact']['count'],'exact rational checks;',result.get('symbolic',{}).get('count',0),'exact symbolic identities.')
    print('Scope: these checks do not formally verify the complete candidate.')
if __name__=='__main__':main()
