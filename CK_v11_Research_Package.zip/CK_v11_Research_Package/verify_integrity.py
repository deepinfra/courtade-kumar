#!/usr/bin/env python3
"""Verify packaged file bytes against SHA256SUMS.txt. Not mathematical verification."""
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parent
n=0
for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
    if not line.strip():continue
    digest,relative=line.split('  ',1)
    p=(ROOT/relative).resolve()
    if not p.is_relative_to(ROOT):raise SystemExit('Unsafe manifest path')
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
        raise SystemExit('Mismatch: '+relative)
    n+=1
print(f'PASS: {n} file hashes; file integrity is not mathematical correctness.')
